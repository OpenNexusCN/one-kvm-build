scrcpy 3.3 (aarch64) 自编译产物备份
构建主机: one-kvm (Armbian 26.11.0 noble / Ubuntu 24.04, aarch64)
构建时间: 2026-11-18 16:27 CST
客户端: scrcpy 3.3 (gcc 13.3.0, meson 1.3.2, SDL2 2.30.0, ffmpeg 6.1.1)
服务端: scrcpy-server v3.3 (官方预编译, 90752 B)
运行依赖: libsdl2-2.0-0 libavcodec60 libavformat60 libavutil58 libavdevice60 libswresample4 libusb-1.0-0
安装: cp usr/local/bin/scrcpy /usr/local/bin/ ; mkdir -p /usr/local/share/scrcpy && cp usr/local/share/scrcpy/scrcpy-server /usr/local/share/scrcpy/
用法(无显示器): scrcpy --no-playback --stay-awake --max-size=1024 --record=/tmp/rec.mp4
用法(指定服务端): SCRCPY_SERVER_PATH=/path/to/scrcpy-server scrcpy ...
重建: tar xf src/v3.3.tar.gz && meson setup build --buildtype=release --strip -Dprebuilt_server=src/scrcpy-server-v3.3 && ninja -C build
